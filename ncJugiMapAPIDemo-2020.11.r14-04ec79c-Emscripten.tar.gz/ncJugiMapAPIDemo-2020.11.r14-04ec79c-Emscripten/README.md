[![Linux](https://github.com/nCine/ncJugiMapAPIDemo/workflows/Linux/badge.svg)](https://github.com/nCine/ncJugiMapAPIDemo/actions?workflow=Linux)
[![macOS](https://github.com/nCine/ncJugiMapAPIDemo/workflows/macOS/badge.svg)](https://github.com/nCine/ncJugiMapAPIDemo/actions?workflow=macOS)
[![Windows](https://github.com/nCine/ncJugiMapAPIDemo/workflows/Windows/badge.svg)](https://github.com/nCine/ncJugiMapAPIDemo/actions?workflow=Windows)
[![MinGW](https://github.com/nCine/ncJugiMapAPIDemo/workflows/MinGW/badge.svg)](https://github.com/nCine/ncJugiMapAPIDemo/actions?workflow=MinGW)
[![Emscripten](https://github.com/nCine/ncJugiMapAPIDemo/workflows/Emscripten/badge.svg)](https://github.com/nCine/ncJugiMapAPIDemo/actions?workflow=Emscripten)
[![Android](https://github.com/nCine/ncJugiMapAPIDemo/workflows/Android/badge.svg)](https://github.com/nCine/ncJugiMapAPIDemo/actions?workflow=Android)
[![CodeQL](https://github.com/nCine/ncJugiMapAPIDemo/workflows/CodeQL/badge.svg)](https://github.com/nCine/ncJugiMapAPIDemo/actions?workflow=CodeQL)

# ncJugiMapAPIDemo
A nCine port of the [JugiMap](http://jugimap.com) [API](https://github.com/Jugilus/JugiMapAPI) Demo test by [Jugilus](https://github.com/Jugilus).

The JugiMap API is distributed under the [MIT License](https://github.com/Jugilus/JugiMapAPI/blob/master/LICENSE) and is Copyright (c) 2019 Jugilus.

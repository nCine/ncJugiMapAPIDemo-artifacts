[![Linux](https://github.com/nCine/ncJugiMapFrameworkDemo/workflows/Linux/badge.svg)](https://github.com/nCine/ncJugiMapFrameworkDemo/actions?workflow=Linux)
[![macOS](https://github.com/nCine/ncJugiMapFrameworkDemo/workflows/macOS/badge.svg)](https://github.com/nCine/ncJugiMapFrameworkDemo/actions?workflow=macOS)
[![Windows](https://github.com/nCine/ncJugiMapFrameworkDemo/workflows/Windows/badge.svg)](https://github.com/nCine/ncJugiMapFrameworkDemo/actions?workflow=Windows)
[![MinGW](https://github.com/nCine/ncJugiMapFrameworkDemo/workflows/MinGW/badge.svg)](https://github.com/nCine/ncJugiMapFrameworkDemo/actions?workflow=MinGW)
[![Emscripten](https://github.com/nCine/ncJugiMapFrameworkDemo/workflows/Emscripten/badge.svg)](https://github.com/nCine/ncJugiMapFrameworkDemo/actions?workflow=Emscripten)
[![Android](https://github.com/nCine/ncJugiMapFrameworkDemo/workflows/Android/badge.svg)](https://github.com/nCine/ncJugiMapFrameworkDemo/actions?workflow=Android)
[![CodeQL](https://github.com/nCine/ncJugiMapFrameworkDemo/workflows/CodeQL/badge.svg)](https://github.com/nCine/ncJugiMapFrameworkDemo/actions?workflow=CodeQL)

# ncJugiMapFrameworkDemo
A nCine port of the [JugiMap](http://jugimap.com) [Framework](https://github.com/Jugilus/JugimapFramework) Demo by [Jugilus](https://github.com/Jugilus).

The JugiMap Framework is distributed under the [MIT License](https://github.com/Jugilus/JugimapFramework/blob/master/LICENSE) and is Copyright (c) 2019 Jugilus.

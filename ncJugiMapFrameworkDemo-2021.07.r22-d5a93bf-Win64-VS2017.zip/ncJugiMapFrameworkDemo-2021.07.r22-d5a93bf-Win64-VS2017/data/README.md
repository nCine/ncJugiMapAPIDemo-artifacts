# Data files for the *ncJugiMapFrameworkDemo* project

## Icons

- The images in the `icons` folder have been created by Angelo Theodorou for the ncJugiMapFrameworkDemo project assembling together images from the media folder of https://github.com/Jugilus/JugiMapFramework
